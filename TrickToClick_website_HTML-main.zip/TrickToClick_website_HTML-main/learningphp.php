<?php
 $v="hi";
 var_dump($v);
 $arr = array(1, 2, 3, 4);
foreach ($arr as $value)
{

$value = $value * 2;
echo "$value <br>";

}
"<br>";
function funTime()
{
echo "Just have fun and enjoy.....";
}
funTime() ."<br>";//calling function
$list=array( array(1,”Jalsa”,”Trivikram”),array(2,”Jhonny”,”PK”));

?>